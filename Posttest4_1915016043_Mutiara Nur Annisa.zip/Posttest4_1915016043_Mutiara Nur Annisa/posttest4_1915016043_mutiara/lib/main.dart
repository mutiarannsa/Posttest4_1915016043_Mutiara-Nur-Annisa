import 'package:flutter/material.dart';
import 'package:posttest4_1915016043_mutiara/myApp.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Posttest 4 Mutiara Nur Annisa',
      home: myApp(),
    );
  }
}
