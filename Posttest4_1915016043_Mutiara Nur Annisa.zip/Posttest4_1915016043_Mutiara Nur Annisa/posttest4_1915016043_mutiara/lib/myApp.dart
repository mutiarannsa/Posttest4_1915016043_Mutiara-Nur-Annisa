// ignore_for_file: file_names, use_key_in_widget_constructors

import 'package:flutter/material.dart';

String alamat = "", detail = "";

class myApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(0xfffF6F3F3),
      body: ListView(children: [
        Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
          Container(
              width: lebar,
              height: tinggi,
              child: Stack(
                fit: StackFit.expand,
                alignment: Alignment.center,
                children: [
                  Positioned(
                    top: 0,
                    width: lebar,
                    height: 274,
                    child: Opacity(
                      opacity: 0.6,
                      child: Container(
                        child: Image.asset(
                          "icecream.png",
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 119,
                    width: lebar,
                    height: 0,
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Ice Cream",
                        overflow: TextOverflow.visible,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          height: 1.2,
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          color: Color(0xfffA68078),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 160,
                    width: lebar,
                    height: 0,
                    child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "by mutiarannsa",
                        overflow: TextOverflow.visible,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          height: 1.2,
                          fontSize: 10,
                          fontWeight: FontWeight.w900,
                          color: Color(0xfffA68078),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    left: 0,
                    top: 327,
                    width: lebar,
                    height: 74,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Center(
                        child: Text(
                          "Your Ice Cream truck is here!",
                          overflow: TextOverflow.visible,
                          style: TextStyle(
                            height: 3,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                      left: 0,
                      top: 486,
                      width: lebar,
                      height: 37,
                      child: Center(
                        child: TextButton(
                          onPressed: () {
                            Navigator.pushReplacement(context,
                                MaterialPageRoute(builder: (_) {
                              return SecondPage();
                            }));
                          },
                          child: Text("Get Started"),
                          style: TextButton.styleFrom(
                              backgroundColor: Color(0xfffA68078),
                              primary: Colors.white),
                        ),
                      ))
                ],
              )),
        ]),
      ]),
    );
  }
}

class SecondPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Posttest 3 Mutiara',
      theme: ThemeData(primarySwatch: Colors.grey),
      home: MySecondPage(),
    );
  }
}

class MySecondPage extends StatefulWidget {
  const MySecondPage({Key? key}) : super(key: key);

  @override
  State<MySecondPage> createState() => _MySecondPageState();
}

class _MySecondPageState extends State<MySecondPage> {
  final alamatCtrl = TextEditingController();
  final detailCtrl = TextEditingController();

  bool isSesuai = false;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    alamatCtrl.dispose();
    detailCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Ice Cream"),
        centerTitle: true,
        backgroundColor: Color(0xfffA68078),
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: MediaQuery.of(context).size.width,
          child: ListView(
            children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 30),
                  Text("Sebelum memulai order, Masukkan detail alamat Anda"),
                  SizedBox(
                    height: 30,
                  ),
                  TextField(
                    maxLines: 1,
                    controller: alamatCtrl,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Alamat",
                      hintText: "Alamat Lengkap Anda",
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    maxLines: 2,
                    controller: detailCtrl,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: "Detail ",
                      hintText: "Detail alamat Anda",
                    ),
                  ),
                  ListTile(
                    title: Text("Apakah Sudah sesuai?"),
                    leading: Checkbox(
                      value: isSesuai,
                      onChanged: (bool? value) {
                        setState(() {
                          isSesuai = value!;
                        });
                      },
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 40,
                width: 20,
                child: TextButton(
                  onPressed: () {
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (_) {
                      //setState(() {
                      alamat = alamatCtrl.text;
                      detail = detailCtrl.text;
                      //});
                      return ThirdPage();
                    }));
                  },
                  child: Text("Submit"),
                  style: TextButton.styleFrom(
                      backgroundColor: Color(0xfffA68078),
                      primary: Colors.white),
                ),
              ),
              SizedBox(height: 30),
              Center(child: Text('Alamat :  $alamat')),
              Center(child: Text('Detail : $detail')),
              Center(
                  child:
                      Text('Inputan ${isSesuai ? "Sesuai" : "Tidak Sesuai"}'))
            ],
          ),
        ),
      ),
    );
  }
}

class ThirdPage extends StatefulWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  State<ThirdPage> createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  @override
  final List<BottomNavigationBarItem> _myItem = const [
    BottomNavigationBarItem(
      icon: Icon(Icons.home),
      label: "Home",
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.search),
      label: "Search",
    ),
    BottomNavigationBarItem(
      icon: Icon(Icons.person),
      label: "Profile",
    ),
  ];

  int _pageIndex = 0;

  @override
  Widget build(BuildContext context) {
    final List<Widget> _myPages = [
      Column(
        children: [
          Container(
            margin: EdgeInsets.all(10),
            child: TextButton(
              child: Icon(Icons.arrow_back),
              style: TextButton.styleFrom(
                  backgroundColor: Color(0xfffA68078), primary: Colors.white),
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) {
                    return SecondPage();
                  }),
                );
              },
            ),
          ),
          Container(
            margin: EdgeInsets.all(5),
            child: Text("Alamat : $alamat\nDetail : $detail"),
          ),
        ],
      ),
      Container(),
      Container(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text("Ice Cream"),
        centerTitle: true,
        backgroundColor: Color(0xfffA68078),
        foregroundColor: Colors.white,
      ),
      body: _myPages.elementAt(_pageIndex),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _pageIndex,
        items: _myItem,
        onTap: (int newIndex) {
          setState(() {
            _pageIndex = newIndex;
          });
        },
      ),
    );
  }
}
